package eStoreProduct.DAO;

import java.util.List;

import eStoreProduct.model.Orders;


public interface OrderDAO {
	public List<Orders> getorderProds();
	public  Orders OrdProductById(Integer productId);
}
