package eStoreProduct.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import eStoreProduct.DAO.OrderDAO;
import eStoreProduct.DAO.ProductDAO;
import eStoreProduct.model.Orders;
import eStoreProduct.model.Product;
@Controller
public class Ordercontroller {
	@Autowired
	private  ProductDAO pdaoimp;
	
	@Autowired
	 private OrderDAO orderdao;
	
	  @RequestMapping("/order")
	  public String showOrders(Model model) {
		  System.out.println("inshow");
	    List<Orders> orderProducts = orderdao. getorderProds();
	    model.addAttribute("orderProducts", orderProducts);
	    return "Orders";
	  }
	  @GetMapping("/productDetails")
	    public String getProductDetails(@RequestParam("id") int productId, Model model) {
	        // Use your product DAO implementation to fetch the product details by ID
	        Orders product = orderdao.OrdProductById( productId);
	        model.addAttribute("product", product);
	        return "OrdProDetails";
	    }

}
