package eStoreProduct.controller;

public class WishlistController {

}
