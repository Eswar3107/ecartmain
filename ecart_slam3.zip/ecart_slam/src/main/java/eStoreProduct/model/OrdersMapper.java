package eStoreProduct.model;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class OrdersMapper implements RowMapper<Orders> {

    @Override
    public Orders mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        int id = resultSet.getInt("prod_id");
        String name = resultSet.getString("prod_title");
        double price = resultSet.getDouble("prod_price");
        String description = resultSet.getString("prod_desc");
        String imageUrl = resultSet.getString("image_url");
        int ordid = resultSet.getInt("ordr_id");
        String ship_stat = resultSet.getString("ordr_shipment_status");

        return new Orders(id, name, price, description, imageUrl, ordid, ship_stat);
    }
}

