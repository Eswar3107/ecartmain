package eStoreProduct.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import eStoreProduct.DAO.OrderDAO;
import eStoreProduct.DAO.ProductDAO;
import eStoreProduct.model.Orders;
import eStoreProduct.model.Product;
@Controller
public class Ordercontroller {
	@Autowired
	private  ProductDAO pdaoimp;
	
	@Autowired
	 private OrderDAO orderdao;
	
	  @RequestMapping("/order")
	  public String showOrders(Model model) {
		  System.out.println("inshow");
	    List<Orders> orderProducts = orderdao. getorderProds();
	    model.addAttribute("orderProducts", orderProducts);
	    return "Orders";
	  }
	  @GetMapping("/productDetails")
	    public String getProductDetails(@RequestParam("id") int productId, Model model) {
	        // Use your product DAO implementation to fetch the product details by ID
	        Orders product = orderdao.OrdProductById( productId);
	        model.addAttribute("product", product);
	        return "OrdProDetails";
	    }
	  
	  @PostMapping("/cancelOrder")
	  @ResponseBody
	  public String cancelOrder(@RequestParam("orderproId") Integer productId) {
	      orderdao.cancelorderbyId(productId);
	     
	      return "Order with ID " +productId + " has been cancelled.";
	  }
	  
	  
	  @RequestMapping(value = "/trackOrder", method = RequestMethod.GET)
	  @ResponseBody
	  public String trackOrder(@RequestParam("orderproId") int orderId) {
	      // Retrieve the shipment status for the given order ID
	      String shipmentStatus = orderdao.getShipmentStatus(orderId);
	      
	      return shipmentStatus;
	  }
	  
	  
	  @PostMapping("/applyFilters")
	  public String applyFilters(@RequestParam("sortBy") String sortBy, Model model) {
	    // Call the appropriate DAO method to fetch filtered/sorted products
	    List<Orders> filteredProducts;
	    if (sortBy.equals("price")) {
	      filteredProducts = orderdao.getProductsSortedByPrice();
	    } else if (sortBy.equals("shipping")) {
	      filteredProducts = orderdao.getProductsSortedByShippingStatus();
	    } else {
	      filteredProducts = orderdao.getorderProds();
	    }
	    
	    // Add the filtered/sorted products to the model
	    model.addAttribute("orderProducts", filteredProducts);
	    
	    // Return the view name for displaying the updated product list
	    return "orders";
	  }



}
