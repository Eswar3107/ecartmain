package eStoreProduct.DAO;

public interface ServicableRegionDAO {
	public boolean getValidityOfPincode(int pincode);
}
