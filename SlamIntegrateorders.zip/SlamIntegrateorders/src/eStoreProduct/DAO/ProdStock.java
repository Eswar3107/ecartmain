package eStoreProduct.DAO;

public class ProdStock {

}