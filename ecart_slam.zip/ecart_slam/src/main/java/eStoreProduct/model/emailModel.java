package eStoreProduct.model;

public class emailModel {
	private String ename;
	private String mailId;
}